NAI角色卡生成器 Android 工程（移植预览版）

当前包含：
- Android Studio 工程源代码（Java + WebView）
- 内置第三阶段角色卡 HTML 原型
- Android 文件选择器，可从手机选择四张图片
- 顶部“打开 NovelAI 图片生成页面”按钮，跳转 https://novelai.net/image

如何生成 APK：
1. 在电脑安装 Android Studio（建议较新版本）。
2. Android Studio -> Open，选择本文件夹（包含 settings.gradle）。
3. 等待 Gradle 同步；安装 Android SDK Platform 35 和对应 Build Tools。
4. Build -> Build Bundle(s) / APK(s) -> Build APK(s)。
5. APK 通常位于 app/build/outputs/apk/debug/app-debug.apk。

重要限制：
- 当前交付的是 Android Studio 工程，不是已经编译好的 APK。本次运行环境没有安装 Android SDK/Gradle，无法在这里产出并真机验证 APK。
- NovelAI 按钮只负责打开官方图片生成页面；用户需要自行登录并手动上传导出的角色卡。没有实现自动登录或自动上传。
- 当前界面仍是浏览器原型的 WebView 包装，核心布局与原 EXE 尚未逐像素验证，不应视为完整 1:1 成品。
